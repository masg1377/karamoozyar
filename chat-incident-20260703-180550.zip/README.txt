﻿CapturedAt: 2026-07-03 18:05:50
Machine: WIN-IS38DJS95SN
User: Administrator
PowerShell: 5.1.20348.1366
